
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: "smtp.rediffmailpro.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    },
    name: "infodartmail.com",   // ✅ IMPORTANT: fixes HeloHost error
    tls: {
        rejectUnauthorized: false
    }
});

const sendEmail = async ({ to, subject, message }) => {
    try {
        if (!to) {
            console.log("EMAIL SKIPPED: No recipient");
            return { success: false, error: "No recipient" };
        }

        const info = await transporter.sendMail({
            from: `"Health Monitor" <${process.env.EMAIL_USER}>`,
            to,
            subject,
            text: message
        });

        console.log("EMAIL SUCCESS:", info.response);

        return {
            success: true,
            data: info.response
        };

    } catch (err) {
        console.log("EMAIL ERROR:", err.response || err.message);

        return {
            success: false,
            error: err.message
        };
    }
};

module.exports = { sendEmail };