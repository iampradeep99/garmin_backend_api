#!/usr/bin/env node

const https = require('https');
const fs = require('fs');
const debug = require('debug')('garminproject:server');
const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
require('dotenv').config();
const {startHealthCron} = require('./crons/healthAlertCron')
const {startSeederCron} = require('./crons/seederCron')



const { connectMongo } = require('./database/mongo');

connectMongo();

const authRouter = require('./routes/auth');
const usersRouter = require('./routes/users');
const garminRouter = require('./routes/garmin');
const garminPushRouter = require('./routes/garminPush');
const thresholdRouter = require('./routes/threshold');
startSeederCron()
startHealthCron();

const app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/auth', authRouter);
app.use('/users', usersRouter);
app.use('/api/garmin', garminRouter);
app.use('/api/garmin/push', garminPushRouter);
app.use('/api/threshold', thresholdRouter);

app.use(function (req, res, next) {
  next(createError(404));
});

app.use(function (err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

const port = normalizePort(process.env.PORT || '443');
app.set('port', port);

const sslOptions = {
  key: fs.readFileSync(path.join(__dirname, 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
};

const server = https.createServer(sslOptions, app);

server.listen(port);
server.on('error', onError);
server.on('listening', onListening);

function normalizePort(val) {
  const port = parseInt(val, 10);
  if (isNaN(port)) return val;
  if (port >= 0) return port;
  return false;
}

function onError(error) {
  if (error.syscall !== 'listen') throw error;

  const bind = typeof port === 'string'
    ? 'Pipe ' + port
    : 'Port ' + port;

  switch (error.code) {
    case 'EACCES':
      console.error(bind + ' requires elevated privileges');
      process.exit(1);
    case 'EADDRINUSE':
      console.error(bind + ' is already in use');
      process.exit(1);
    default:
      throw error;
  }
}

function onListening() {
  const addr = server.address();
  const bind = typeof addr === 'string'
    ? 'pipe ' + addr
    : 'port ' + addr.port;
  debug('Listening on ' + bind);
  console.log(`Server running on https://localhost:${addr.port}`);
}
